# SentinelPrompt

**Agentic Prompt Injection Firewall**

SentinelPrompt is a runnable hackathon prototype that inspects untrusted text before it reaches an AI agent, identifies common prompt-injection patterns, applies a risk-based policy, redacts suspicious spans, signs the verdict and independently authorizes proposed tool actions.

> Scope transparency: this repository implements a functional text-inspection vertical slice. Multimodal parsing, OCR, external-model adjudication, enterprise IAM and persistent audit storage are production extensions described in the architecture, not claimed as completed code.

## What judges can demonstrate

- Benign content returns `ALLOW`.
- Prompt-injection content produces findings, risk scoring and safe content.
- Sensitive tool actions return `REQUIRE_APPROVAL`.
- High-risk content blocks tool authorization.
- Every inspection contains a versioned HMAC signature.
- A responsive web console and OpenAPI interface are included.
- Automated API tests validate core flows.

## Architecture

```mermaid
flowchart LR
  A[Untrusted content] --> B[FastAPI gateway]
  B --> C[Detection mesh]
  C --> D[Risk and policy]
  D --> E[Sanitize or block]
  D --> F[Signed verdict]
  F --> G[AI agent]
  G --> H[Tool authorization proxy]
```

See [`docs/architecture.md`](docs/architecture.md) for trust boundaries and production evolution.

## Technology stack

- Python 3.12
- FastAPI and Pydantic
- Uvicorn
- HTML, CSS and JavaScript web console
- Pytest and HTTPX
- Docker and Docker Compose

## Prerequisites

Choose one:

- Python 3.12 or later, or
- Docker with Docker Compose

## Local installation

```bash
git clone <YOUR_PUBLIC_REPOSITORY_URL>
cd sentinelprompt-repository
python -m venv .venv
```

Activate the virtual environment:

```bash
# Linux or macOS
source .venv/bin/activate

# Windows PowerShell
.venv\Scripts\Activate.ps1
```

Install dependencies and configure the environment:

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

On Windows, copy `.env.example` to `.env` manually or run:

```powershell
Copy-Item .env.example .env
```

Replace `SIGNING_KEY` in `.env` with a long random development secret.

## Run the project

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open:

- Web console: `http://localhost:8000`
- OpenAPI: `http://localhost:8000/docs`
- Health check: `http://localhost:8000/health`

## Docker setup

```bash
cp .env.example .env
docker compose up --build
```

Then open `http://localhost:8000`.

## Environment variables

| Variable | Required | Purpose |
|---|---:|---|
| `APP_ENV` | No | Runtime environment label. |
| `HOST` | No | Bind address used by deployment scripts. |
| `PORT` | No | Service port. |
| `SIGNING_KEY` | Yes outside local demonstration | HMAC key used to sign verdict metadata. |
| `LOG_LEVEL` | No | Logging level for future structured logging integration. |

Never commit `.env` or real credentials.

## Quick demonstration

Safe request:

```bash
curl -s http://localhost:8000/v1/inspect \
  -H 'Content-Type: application/json' \
  -d @samples/benign.json
```

Controlled attack request:

```bash
curl -s http://localhost:8000/v1/inspect \
  -H 'Content-Type: application/json' \
  -d @samples/attack.json
```

Sensitive tool request:

```bash
curl -s http://localhost:8000/v1/tools/authorize \
  -H 'Content-Type: application/json' \
  -d '{"tool":"mail","impact":"external_send","content_risk":20}'
```

## Testing

```bash
pytest -q
```

The tests cover benign inspection, prompt-injection handling and approval enforcement for sensitive tools.

## API documentation

See [`docs/api.md`](docs/api.md). Running the service also exposes interactive OpenAPI documentation at `/docs`.

## Repository layout

```text
app/                 FastAPI service and web console
  main.py            API routes and decision logic
  models.py          Request and response contracts
  detectors.py       Detection and redaction logic
  security.py        HMAC verdict signing
  static/index.html  Demonstration UI
docs/                Architecture, API and demo documentation
samples/             Synthetic benign and attack payloads
tests/               Automated API tests
.env.example         Safe environment template
Dockerfile           Container image definition
docker-compose.yml   One-command local deployment
requirements.txt     Python dependency lock list
```

## Security design

- External content is treated as untrusted data.
- Detection produces explicit evidence spans.
- Redaction occurs before safe content is returned.
- Verdict metadata is signed.
- Tool authorization is separate from model reasoning.
- Sensitive actions require independent approval.

This prototype is educational and must not be used as the sole security control for production AI systems.

## Known limitations

- Text-only input in the implemented vertical slice.
- Pattern-based detectors are demonstrative, not a comprehensive classifier.
- Capability tokens are prototype identifiers, not production credentials.
- No database-backed audit log or analyst workflow.
- No production key management, malware scanning, tenant isolation or rate limiting.

## Demo and contribution guidance

See [`docs/demo-guide.md`](docs/demo-guide.md). Open a pull request for changes and avoid committing sensitive information.
