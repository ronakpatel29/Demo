# Demo guide

1. Start the service and open the web console.
2. Submit `Summarize this customer support document.` and show `ALLOW`.
3. Select **Load attack sample**, inspect it and show the evidence, risk and sanitized content.
4. Open `/docs` and run `POST /v1/tools/authorize` with `impact` set to `external_send`; show `REQUIRE_APPROVAL`.
5. Run `pytest -q` and show all tests passing.

Only synthetic demonstration data should be used. Never enter real credentials, customer data or confidential prompts.
