# Architecture overview

```mermaid
flowchart LR
  A[User, file, web, email or API content] --> B[Ingress gateway]
  B --> C[Canonicalization and trust labels]
  C --> D[Detection mesh]
  D --> E[Risk and policy engine]
  E -->|Allow| F[Signed verdict envelope]
  E -->|Sanitize| G[Span redaction and safe content]
  E -->|Quarantine or block| H[Audit and analyst review]
  F --> I[Downstream AI agent]
  G --> I
  I --> J[Tool authorization proxy]
  J --> K[Enterprise tools]
  K --> B
```

## Trust boundaries
1. Raw external content is untrusted.
2. Only a signed verdict envelope enters downstream context.
3. The model may propose a tool action but cannot execute it directly.
4. Tool results are inspected before returning to agent context.

## Prototype implementation
The repository implements the inspection gateway, rule-based detection mesh, risk decision, content redaction, HMAC verdict signing, tool authorization endpoint, web console and automated tests. OCR, full document parsing, external model adjudication, persistent audit storage and enterprise IAM integration are documented production extensions rather than represented as completed functionality.
