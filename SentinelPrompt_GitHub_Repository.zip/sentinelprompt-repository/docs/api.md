# API documentation

Interactive OpenAPI documentation is available at `/docs` when the service is running.

## `GET /health`
Returns service and policy status.

## `POST /v1/inspect`
Request:
```json
{"content":"Summarize this document","source_type":"text","session_id":"demo-1"}
```
Response includes request ID, decision, risk score, findings, sanitized content, policy version and HMAC signature.

## `POST /v1/tools/authorize`
Request:
```json
{"tool":"mail","destination":"external@example.test","impact":"external_send","content_risk":20}
```
Sensitive impacts return `REQUIRE_APPROVAL`; high-risk content is blocked; permitted read-only actions receive a prototype capability token.
