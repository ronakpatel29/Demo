from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field

class Decision(str, Enum):
    ALLOW="ALLOW"; SANITIZE="SANITIZE"; QUARANTINE="QUARANTINE"; BLOCK="BLOCK"; REQUIRE_APPROVAL="REQUIRE_APPROVAL"

class InspectRequest(BaseModel):
    content: str = Field(min_length=1, max_length=100000)
    source_type: str = "text"
    session_id: Optional[str] = None
    requested_tool: Optional[str] = None

class Finding(BaseModel):
    attack_type: str
    confidence: float
    severity: int
    evidence: str
    start: int
    end: int

class InspectResponse(BaseModel):
    request_id: str
    decision: Decision
    risk_score: int
    findings: List[Finding]
    safe_content: str
    policy_version: str
    signature: str

class ToolRequest(BaseModel):
    tool: str
    destination: Optional[str] = None
    impact: str = "read_only"
    content_risk: int = Field(ge=0, le=100)

class ToolResponse(BaseModel):
    decision: Decision
    reason: str
    capability_token: Optional[str] = None
