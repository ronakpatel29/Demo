import base64, re
from typing import List, Tuple
from .models import Finding

PATTERNS = {
 "INSTRUCTION_OVERRIDE": [r"ignore (all |any )?(previous|prior) instructions", r"disregard (the )?(system|developer) prompt", r"override (the )?rules"],
 "ROLE_CHANGE": [r"you are now", r"act as (an? )?(admin|developer|system)", r"developer mode", r"\bDAN\b"],
 "SECRET_EXTRACTION": [r"reveal (the )?(system prompt|secret|api key|token)", r"show (me )?(your )?(hidden|internal) instructions", r"dump (memory|credentials)"],
 "TOOL_ABUSE": [r"send .* to .*external", r"delete (all|the)", r"execute (this )?(command|script)", r"change .* permissions"],
 "CREDENTIAL_THEFT": [r"enter (your )?(password|otp|token)", r"share (your )?(credentials|api key)", r"verify .* login"],
 "CONTEXT_POISONING": [r"remember this (as|forever)", r"store this in memory", r"from now on .* policy"],
 "MULTI_STEP_JAILBREAK": [r"step 1.*step 2", r"hypothetical.*ignore", r"for research purposes.*bypass"],
 "INDIRECT_INJECTION": [r"when an ai reads this", r"instructions for the assistant", r"retrieved document.*ignore"]
}

def _finding(kind:str, text:str, match:re.Match, confidence=.92, severity=4):
    return Finding(attack_type=kind, confidence=confidence, severity=severity, evidence=match.group(0), start=match.start(), end=match.end())

def inspect_text(text:str) -> Tuple[List[Finding], str]:
    findings=[]
    for kind, patterns in PATTERNS.items():
        for p in patterns:
            for m in re.finditer(p, text, re.I|re.S): findings.append(_finding(kind,text,m))
    # bounded Base64 decoding
    for m in re.finditer(r"\b[A-Za-z0-9+/]{20,}={0,2}\b", text):
        try:
            decoded=base64.b64decode(m.group(0), validate=True).decode("utf-8", "ignore")
            if decoded and any(re.search(p, decoded, re.I|re.S) for ps in PATTERNS.values() for p in ps):
                findings.append(Finding(attack_type="ENCODED_INSTRUCTIONS",confidence=.97,severity=5,evidence=m.group(0)[:80],start=m.start(),end=m.end()))
        except Exception: pass
    safe=text
    for f in sorted(findings,key=lambda x:x.start,reverse=True): safe=safe[:f.start]+"[REDACTED SECURITY INSTRUCTION]"+safe[f.end:]
    return findings, safe
