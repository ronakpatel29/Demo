from pathlib import Path
from uuid import uuid4
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from .models import *
from .detectors import inspect_text
from .security import sign_payload

app=FastAPI(title="SentinelPrompt API",version="1.0.0",description="Agentic prompt-injection firewall prototype")
STATIC=Path(__file__).parent/"static"
app.mount("/static",StaticFiles(directory=STATIC),name="static")

@app.get("/",include_in_schema=False)
def home(): return FileResponse(STATIC/"index.html")

@app.get("/health")
def health(): return {"status":"ok","policy_version":"v1"}

@app.post("/v1/inspect",response_model=InspectResponse)
def inspect(req:InspectRequest):
    findings,safe=inspect_text(req.content)
    if not findings: score,decision=5,Decision.ALLOW
    else:
        max_sev=max(x.severity for x in findings); score=min(100, 35+max_sev*10+min(20,(len(findings)-1)*5))
        decision=Decision.BLOCK if score>=75 else Decision.QUARANTINE if score>=50 else Decision.SANITIZE
    rid=f"req-{uuid4().hex[:12]}"
    core={"request_id":rid,"decision":decision.value,"risk_score":score,"policy_version":"v1"}
    return InspectResponse(**core,findings=findings,safe_content=safe,signature=sign_payload(core))

@app.post("/v1/tools/authorize",response_model=ToolResponse)
def authorize(req:ToolRequest):
    sensitive={"external_send","delete","privilege_change","secret_read"}
    if req.content_risk>=75: return ToolResponse(decision=Decision.BLOCK,reason="Content risk exceeds policy threshold")
    if req.impact in sensitive: return ToolResponse(decision=Decision.REQUIRE_APPROVAL,reason="Sensitive action requires independent approval")
    token=f"cap-{uuid4().hex}"
    return ToolResponse(decision=Decision.ALLOW,reason="Read-only action permitted",capability_token=token)
