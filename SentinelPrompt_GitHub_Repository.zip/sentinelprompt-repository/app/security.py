import hashlib, hmac, json, os

def sign_payload(payload:dict)->str:
    key=os.getenv("SIGNING_KEY","development-only-change-me").encode()
    body=json.dumps(payload,sort_keys=True,separators=(",",":")).encode()
    return hmac.new(key,body,hashlib.sha256).hexdigest()
